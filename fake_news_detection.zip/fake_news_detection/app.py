import streamlit as st
import pandas as pd
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

# Load model and vectorizer
with open("model.pkl", "rb") as model_file:
    model = pickle.load(model_file)
with open("vectorizer.pkl", "rb") as vec_file:
    vectorizer = pickle.load(vec_file)

st.title("Fake News Detection App")
st.write("Upload a CSV file or type text to check if the news is real or fake.")

# File upload option
uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])
if uploaded_file:
    data = pd.read_csv(uploaded_file)
    st.write("Uploaded data preview:")
    st.dataframe(data.head())
    if 'text' in data.columns:
        # Predict on the file's text column
        transformed_text = vectorizer.transform(data['text'])
        predictions = model.predict(transformed_text)
        data['Prediction'] = predictions
        st.write("Prediction Results:")
        st.dataframe(data[['text', 'Prediction']])

# Text input option
user_text = st.text_area("Or, type or paste news content here:")
if user_text:
    transformed_text = vectorizer.transform([user_text])
    prediction = model.predict(transformed_text)
    result = "Real" if prediction[0] == 1 else "Fake"
    st.write(f"The entered news is likely: **{result}**")

# Additional Insights
st.write("## Data Insights")
if uploaded_file:
    # Show some basic visualizations
    st.bar_chart(data['Prediction'].value_counts())
