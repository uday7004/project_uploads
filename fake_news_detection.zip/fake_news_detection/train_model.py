import pandas as pd
import numpy as np
import re
import string
import pickle
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix

# Load the datasets
fake_news_df = pd.read_csv("Fake.csv", low_memory=False)[['title', 'text', 'subject', 'date']]
true_news_df = pd.read_csv("True.csv", low_memory=False)

# Add a class column
fake_news_df['class'] = 0
true_news_df['class'] = 1

# Merge datasets
merged_df = pd.concat([true_news_df, fake_news_df], ignore_index=True)

# Drop missing values
merged_df.dropna(inplace=True)

# Function to process text
def processText(text):
    if isinstance(text, str):  # Ensure the text is a string
        text = text.lower()
        text = re.sub('\[.*?\]', '', text)
        text = re.sub("\\W", " ", text)
        text = re.sub('https?://\S+|www\.\S+', '', text)
        text = re.sub('<.*?>+', '', text)
        text = re.sub('[%s]' % re.escape(string.punctuation), '', text)
        text = re.sub('\n', '', text)
        text = re.sub('\w*\d\w*', '', text)
        return text
    return ''  # Return empty string for non-string types

# Process the text column
merged_df['text'] = merged_df['text'].apply(processText)

# Split data into features and target
X = merged_df['text']
y = merged_df['class']

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# Vectorize the text data
vectorizer = TfidfVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Train the model
model = DecisionTreeClassifier(random_state=42)
model.fit(X_train_vec, y_train)

# Save the model and vectorizer
pickle.dump(model, open('model.pkl', 'wb'))
pickle.dump(vectorizer, open('vectorizer.pkl', 'wb'))

# Predictions
predictions = model.predict(X_test_vec)

# Print classification report
print(classification_report(y_test, predictions))

# Print confusion matrix
print(confusion_matrix(y_test, predictions))
